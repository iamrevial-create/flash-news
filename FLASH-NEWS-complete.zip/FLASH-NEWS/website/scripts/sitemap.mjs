// Generates public/sitemap.xml from published articles. Set SITE_URL (e.g. https://flashnews.example). Fails soft.
import { readFileSync, writeFileSync, existsSync } from 'node:fs'
const env = { ...(existsSync('.env') ? Object.fromEntries(readFileSync('.env', 'utf8').split('\n').filter(l => l.includes('=')).map(l => l.split(/=(.*)/s).slice(0, 2))) : {}), ...process.env }
const site = (env.SITE_URL || '').replace(/\/$/, ''), url = env.VITE_SUPABASE_URL, key = env.VITE_SUPABASE_PUBLISHABLE_KEY
if (!site || !url || !key) { console.log('sitemap: SITE_URL / Supabase env missing, skipped'); process.exit(0) }
const h = { apikey: key, Authorization: `Bearer ${key}` }
const get = async p => { const r = await fetch(`${url}/rest/v1/${p}`, { headers: h }); if (!r.ok) throw new Error(`${p}: ${r.status}`); return r.json() }
try {
  const [arts, cats] = await Promise.all([get(`articles?select=slug,updated_at&status=eq.published&order=published_at.desc&limit=5000`), get('categories?select=slug')])
  const u = (loc, last) => `<url><loc>${site}${loc}</loc>${last ? `<lastmod>${last.slice(0, 10)}</lastmod>` : ''}</url>`
  writeFileSync('public/sitemap.xml', `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${[u('/'), ...cats.map(c => u(`/category/${c.slug}`)), ...arts.map(a => u(`/news/${a.slug}`, a.updated_at))].join('\n')}\n</urlset>\n`)
  writeFileSync('public/robots.txt', `User-agent: *\nDisallow: /admin\nDisallow: /editor\nDisallow: /publisher\nAllow: /\nSitemap: ${site}/sitemap.xml\n`)
  console.log(`sitemap: ${arts.length} articles`)
} catch (e) { console.log('sitemap skipped:', e.message) }
