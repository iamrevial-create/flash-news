import { useEffect, useRef } from 'react'
// Runs fn on mount, on an interval, and whenever the tab regains focus, so screens stay current without pressing F5.
export function useAutoRefresh(fn: () => void, ms = 15000, deps: unknown[] = []) {
  const ref = useRef(fn); ref.current = fn
  useEffect(() => {
    const run = () => { if (document.visibilityState === 'visible') ref.current() }
    run(); const t = setInterval(run, ms)
    window.addEventListener('focus', run); document.addEventListener('visibilitychange', run)
    return () => { clearInterval(t); window.removeEventListener('focus', run); document.removeEventListener('visibilitychange', run) }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [ms, ...deps])
}
