export const readingTime = (body: string) => Math.max(1, Math.round(body.trim().split(/\s+/).filter(Boolean).length / 220))
export const slugify = (t: string) => t.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '')
export const isHttpUrl = (u: string) => /^https?:\/\/\S+$/i.test(u)
export const timeAgo = (iso?: string | null, now = Date.now()) => {
  if (!iso) return ''
  const m = (now - new Date(iso).getTime()) / 60000
  if (m < 1) return 'just now'
  if (m < 60) return `${Math.floor(m)} min ago`
  if (m < 1440) return `${Math.floor(m / 60)} h ago`
  return new Date(iso).toLocaleDateString()
}
export const ALLOWED_IMAGES = ['image/jpeg', 'image/png', 'image/webp']
export const MAX_IMAGE = 5 * 1024 * 1024
export const parseTags = (s: string) => {
  const seen = new Set<string>()
  return s.split(',').map(t => t.trim()).filter(Boolean).map(name => ({ name: name.slice(0, 60), slug: slugify(name).slice(0, 60) }))
    .filter(t => t.slug && !seen.has(t.slug) && seen.add(t.slug)).slice(0, 8)
}
export type Embed = { kind: 'iframe' | 'file'; src: string } | null
export const toEmbed = (url: string, storageBase = ''): Embed => {
  if (!url) return null
  const yt = url.match(/^https:\/\/(?:www\.)?(?:youtube\.com\/watch\?(?:.*&)?v=|youtu\.be\/)([\w-]{11})/)
  if (yt) return { kind: 'iframe', src: `https://www.youtube-nocookie.com/embed/${yt[1]}` }
  const vm = url.match(/^https:\/\/(?:www\.)?vimeo\.com\/(\d+)/)
  if (vm) return { kind: 'iframe', src: `https://player.vimeo.com/video/${vm[1]}` }
  if (storageBase && url.startsWith(storageBase) && /\.(mp4|webm)(\?.*)?$/i.test(url)) return { kind: 'file', src: url }
  return null
}
export const MEDIA_IMAGE_MAX = 10 * 1024 * 1024
export const MEDIA_VIDEO_MAX = 50 * 1024 * 1024
export const MEDIA_TYPES = ['image/jpeg', 'image/png', 'image/webp', 'video/mp4', 'video/webm']
export const money = (n: number, cur = 'NGN') => new Intl.NumberFormat(undefined, { style: 'currency', currency: cur, maximumFractionDigits: 2 }).format(n)
