import { supabase } from './supabase'
export const MEDIA_BASE = `${import.meta.env.VITE_SUPABASE_URL}/storage/v1/object/public/publisher-media/`
export interface Media { id: string; path: string; alt_text: string | null; caption: string | null; mime: string | null; size_bytes: number | null; created_at: string }
export const mediaUrl = (path: string) => supabase.storage.from('publisher-media').getPublicUrl(path).data.publicUrl
export const isVideo = (m: { mime: string | null }) => !!m.mime?.startsWith('video/')
