export type Role = 'reader'|'applicant'|'publisher'|'reporter'|'editor'|'admin'
export type Status = 'draft'|'submitted'|'in_review'|'changes_requested'|'approved'|'scheduled'|'published'|'rejected'|'archived'
export interface Profile { id:string; display_name:string; slug:string|null; bio:string|null; avatar_url:string|null; country:string|null; website:string|null; role:Role; status:'active'|'suspended'; verified:boolean }
export interface Article { id:string; slug:string; headline:string; subheadline:string|null; summary:string|null; body:string; featured_image_url:string|null; image_alt:string|null; image_caption:string|null; author_id:string; byline:string|null; category_id:number; status:Status; content_type:string; is_sponsored:boolean; is_breaking:boolean; is_featured:boolean; source_note:string|null; video_url:string|null; review_note:string|null; created_at:string; updated_at:string; submitted_at:string|null; published_at:string|null; scheduled_at:string|null;
  categories?:{slug:string;name:string}|null; profiles?:{display_name:string;slug:string|null;verified:boolean}|null }
export interface Category { id:number; slug:string; name:string }
export const ARTICLE_SELECT = '*, categories(slug,name), profiles!articles_author_id_fkey(display_name,slug,verified)'
export const CONTENT_TYPES = [['original_reporting','Original reporting'],['opinion','Opinion'],['press_release','Press release'],['external','Externally sourced']] as const
