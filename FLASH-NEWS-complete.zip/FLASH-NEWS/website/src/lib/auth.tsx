import { createContext, useContext, useEffect, useState, ReactNode } from 'react'
import type { Session } from '@supabase/supabase-js'
import { supabase } from './supabase'
import type { Profile, Role } from './types'
import { useAutoRefresh } from './useAutoRefresh'
interface Ctx { session: Session|null; profile: Profile|null; loading: boolean; refresh: () => Promise<void>; signOut: () => Promise<void> }
const C = createContext<Ctx>({ session:null, profile:null, loading:true, refresh:async()=>{}, signOut:async()=>{} })
export const useAuth = () => useContext(C)
export const isEditor = (r?: Role) => r === 'editor' || r === 'admin'
export const canWrite = (r?: Role) => r === 'publisher' || r === 'reporter' || r === 'editor' || r === 'admin'
export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session|null>(null)
  const [profile, setProfile] = useState<Profile|null>(null)
  const [loading, setLoading] = useState(true)
  const load = async (s: Session|null) => {
    if (!s) { setProfile(null); return }
    const { data } = await supabase.from('profiles').select('*').eq('id', s.user.id).maybeSingle()
    setProfile((data as Profile) ?? null)
  }
  useEffect(() => {
    supabase.auth.getSession().then(async ({ data }) => { setSession(data.session); await load(data.session); setLoading(false) })
    const { data: sub } = supabase.auth.onAuthStateChange((_e, s) => { setSession(s); setTimeout(() => load(s), 0) })
    return () => sub.subscription.unsubscribe()
  }, [])
  useAutoRefresh(() => { if (session) load(session) }, 20000, [session?.user.id])
  return <C.Provider value={{ session, profile, loading, refresh: () => load(session), signOut: async () => { await supabase.auth.signOut() } }}>{children}</C.Provider>
}
