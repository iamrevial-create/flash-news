import { describe, it, expect } from 'vitest'
import { readingTime, slugify, isHttpUrl, timeAgo, parseTags, toEmbed } from './util'
describe('util', () => {
  it('estimates reading time', () => { expect(readingTime('word '.repeat(440))).toBe(2); expect(readingTime('')).toBe(1) })
  it('slugifies', () => expect(slugify('  Hello, Lagos! ')).toBe('hello-lagos'))
  it('validates urls', () => { expect(isHttpUrl('https://a.com')).toBe(true); expect(isHttpUrl('javascript:alert(1)')).toBe(false) })
  it('formats relative time', () => { const n = Date.now(); expect(timeAgo(new Date(n - 5 * 60000).toISOString(), n)).toBe('5 min ago') })
  it('parses and dedupes tags', () => { expect(parseTags('Lagos, lagos, Elections 2027,  ')).toEqual([{ name: 'Lagos', slug: 'lagos' }, { name: 'Elections 2027', slug: 'elections-2027' }]); expect(parseTags('a,b,c,d,e,f,g,h,i,j')).toHaveLength(8) })
  it('builds safe video embeds', () => {
    expect(toEmbed('https://youtu.be/dQw4w9WgXcQ')).toEqual({ kind: 'iframe', src: 'https://www.youtube-nocookie.com/embed/dQw4w9WgXcQ' })
    expect(toEmbed('https://vimeo.com/12345')?.src).toBe('https://player.vimeo.com/video/12345')
    expect(toEmbed('https://x.supabase.co/storage/v1/object/public/publisher-media/u/a.mp4', 'https://x.supabase.co/storage/v1/object/public/publisher-media/')?.kind).toBe('file')
    expect(toEmbed('https://evil.com/a.mp4', 'https://x.supabase.co/storage/')).toBeNull()
    expect(toEmbed('javascript:alert(1)')).toBeNull()
  })
})
