import { useState, useCallback, FormEvent } from 'react'
import { supabase } from '../lib/supabase'
import { useAutoRefresh } from '../lib/useAutoRefresh'
import { money } from '../lib/util'
interface E { views: number; rate: number; currency: string; view_earned: number; creator_share: number; editor_share: number; earned: number; paid: number; pending: number; available: number }
interface P { id: string; amount: number; currency: string; status: string; admin_note: string | null; created_at: string }
export default function Earnings() {
  const [e, setE] = useState<E | null>(null); const [hist, setHist] = useState<P[]>([]); const [amt, setAmt] = useState(''); const [note, setNote] = useState(''); const [msg, setMsg] = useState('')
  const load = useCallback(() => {
    supabase.rpc('my_earnings').then(({ data }) => setE(data as E))
    supabase.from('payout_requests').select('id,amount,currency,status,admin_note,created_at').order('created_at', { ascending: false }).limit(10).then(({ data }) => setHist((data ?? []) as P[]))
  }, [])
  useAutoRefresh(load, 30000)
  const submit = async (ev: FormEvent) => { ev.preventDefault(); setMsg('')
    const { error } = await supabase.rpc('request_payout', { p_amount: Number(amt), p_note: note }); if (error) return setMsg(error.message)
    setAmt(''); setNote(''); setMsg('Payout request sent. An admin will pay you manually and mark it paid.'); load() }
  if (!e) return null
  return <section className="mt-8" aria-labelledby="earn"><h2 id="earn" className="font-bold text-lg mb-2">Earnings</h2>
    {e.rate <= 0 && e.earned <= 0 && e.paid <= 0 ? <p className="text-sm text-gray-500">Nothing earned yet. Earnings come from a per-view rate and from a share of advertising and sponsor income, both set by the admin. Payments are made manually.</p> : <>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3"><div className="p-3 bg-soft dark:bg-gray-800 rounded"><div className="text-2xl font-black">{money(e.available, e.currency)}</div><div className="text-xs">Available to request</div></div>
        <div className="p-3 bg-soft dark:bg-gray-800 rounded"><div className="text-2xl font-black">{money(e.earned, e.currency)}</div><div className="text-xs">Estimated total earned</div></div>
        <div className="p-3 bg-soft dark:bg-gray-800 rounded"><div className="text-2xl font-black">{money(e.pending, e.currency)}</div><div className="text-xs">Pending payout</div></div>
        <div className="p-3 bg-soft dark:bg-gray-800 rounded"><div className="text-2xl font-black">{money(e.paid, e.currency)}</div><div className="text-xs">Paid</div></div></div>
      <p className="text-xs text-gray-500 mt-2">Breakdown: views {money(e.view_earned, e.currency)} ({money(e.rate, e.currency)} per 1,000, {e.views} views) · revenue share on your stories {money(e.creator_share, e.currency)} · editorial share {money(e.editor_share, e.currency)}. Revenue shares are added only after the admin records and distributes real income. Everything is an estimate until you are paid.</p>
      {e.available > 0 && <form onSubmit={submit} className="grid sm:grid-cols-3 gap-2 mt-3 items-end"><div><label className="label" htmlFor="pa">Amount</label><input id="pa" className="input" type="number" min="1" step="0.01" max={e.available} required value={amt} onChange={x => setAmt(x.target.value)} /></div>
        <div className="sm:col-span-2"><label className="label" htmlFor="pn">How should we pay you? (bank, account name and number, or mobile money)</label><input id="pn" className="input" required maxLength={500} value={note} onChange={x => setNote(x.target.value)} /></div>
        <button className="btn sm:col-span-3 sm:w-fit">Request payout</button></form>}
      {msg && <p role="status" className="text-sm mt-2">{msg}</p>}
      {hist.length > 0 && <ul className="mt-3 text-sm divide-y dark:divide-gray-700">{hist.map(h => <li key={h.id} className="py-1">{money(h.amount, h.currency)} · <b>{h.status}</b> · {new Date(h.created_at).toLocaleDateString()}{h.admin_note && ` · ${h.admin_note}`}</li>)}</ul>}</>}</section>
}
