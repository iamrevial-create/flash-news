import { useState } from 'react'
export default function CookieBanner() {
  const [show, setShow] = useState(() => !localStorage.getItem('fn-consent'))
  if (!show) return null
  const ok = (v: string) => { localStorage.setItem('fn-consent', v); setShow(false) }
  return <div role="dialog" aria-label="Cookie notice" className="fixed bottom-0 inset-x-0 z-30 bg-ink text-gray-100 p-4 text-sm flex flex-wrap gap-3 items-center justify-between">
    <p className="max-w-3xl">We use essential storage to keep you signed in and remember your theme. We do not use advertising or analytics cookies.</p>
    <div className="flex gap-2"><button className="btn" onClick={() => ok('essential')}>Got it</button></div></div>
}
