import { useEffect, useState, FormEvent } from 'react'
import { Link, NavLink, Outlet, useNavigate } from 'react-router-dom'
import { useAuth, isEditor, canWrite } from '../lib/auth'
import { supabase } from '../lib/supabase'
import type { Category, Article } from '../lib/types'
import CookieBanner from './CookieBanner'
import Logo from './Logo'
import { useAutoRefresh } from '../lib/useAutoRefresh'
export default function Layout() {
  const { session, profile, signOut } = useAuth(); const nav = useNavigate()
  const [cats, setCats] = useState<Category[]>([]); const [open, setOpen] = useState(false)
  const [dark, setDark] = useState(() => localStorage.getItem('fn-theme') === 'dark')
  const [unread, setUnread] = useState(0)
  const [breaking, setBreaking] = useState<Article[]>([]); const [q, setQ] = useState('')
  useEffect(() => { document.documentElement.classList.toggle('dark', dark); localStorage.setItem('fn-theme', dark ? 'dark' : 'light') }, [dark])
  useEffect(() => {
    supabase.from('categories').select('*').order('sort').then(({ data }) => setCats((data ?? []) as Category[]))
  }, [])
  useAutoRefresh(() => { supabase.from('articles').select('id,slug,headline').eq('is_breaking', true).eq('status', 'published').order('published_at', { ascending: false }).limit(5)
    .then(({ data }) => setBreaking((data ?? []) as Article[])) })
  useAutoRefresh(() => { if (!session) { setUnread(0); return }
    supabase.from('notifications').select('id', { count: 'exact', head: true }).eq('read', false).then(({ count }) => setUnread(count ?? 0)) }, 15000, [session?.user.id])
  const search = (e: FormEvent) => { e.preventDefault(); if (q.trim()) nav(`/search?q=${encodeURIComponent(q.trim())}`) }
  const link = ({ isActive }: { isActive: boolean }) => `px-3 py-1 text-sm font-semibold whitespace-nowrap rounded-full ${isActive ? 'bg-brand text-white' : 'hover:bg-soft dark:hover:bg-gray-800'}`
  return (
    <div className="min-h-screen flex flex-col">
      <div className="bg-ink text-gray-300 text-xs"><div className="max-w-6xl mx-auto px-4 py-1 flex justify-between"><span>{new Date().toLocaleDateString(undefined, { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</span><a href="#newsletter" className="hover:text-white">Newsletter</a></div></div>
      <header className="sticky top-0 z-20 bg-white dark:bg-ink border-b-4 border-brand">
        <div className="max-w-6xl mx-auto px-4 py-2 flex items-center gap-3 flex-wrap">
          <button className="lg:hidden btn btn-ghost" aria-label="Menu" aria-expanded={open} onClick={() => setOpen(!open)}>☰</button>
          <Logo />
          <form onSubmit={search} role="search" className="ml-auto"><input className="input !w-40" value={q} onChange={e => setQ(e.target.value)} placeholder="Search news" aria-label="Search news" /></form>
          <button className="btn btn-ghost" onClick={() => setDark(!dark)} aria-label="Toggle dark mode">◐</button>
          {session ? <>
            <Link className="btn btn-ghost" to="/saved">Saved</Link><Link className="btn btn-ghost" to="/notifications" aria-label={`Notifications, ${unread} unread`}>🔔{unread > 0 && <span className="ml-1 bg-brand text-white rounded-full px-1.5 text-xs">{unread}</span>}</Link>
            {canWrite(profile?.role) && <Link className="btn" to="/publisher/dashboard">Publisher</Link>}
            {isEditor(profile?.role) && <Link className="btn btn-ghost" to="/editor">Editor</Link>}
            {profile?.role === 'admin' && <Link className="btn btn-ghost" to="/admin">Admin</Link>}
            {!canWrite(profile?.role) && <Link className="btn" to="/become-a-publisher">Become a Publisher</Link>}
            <button className="btn btn-ghost" onClick={() => signOut().then(() => nav('/'))}>Sign out</button></>
          : <><Link className="btn btn-ghost" to="/sign-in">Sign In</Link><Link className="btn" to="/become-a-publisher">Become a Publisher</Link></>}
        </div>
        <nav aria-label="Categories" className={`max-w-6xl mx-auto px-4 pb-2 gap-1 overflow-x-auto ${open ? 'flex flex-col' : 'hidden'} lg:flex`}>
          <NavLink to="/" end className={link}>Home</NavLink>
          {cats.map(c => <NavLink key={c.id} to={`/category/${c.slug}`} className={link} onClick={() => setOpen(false)}>{c.name}</NavLink>)}
        </nav>
      </header>
      {breaking.length > 0 && <div className="bg-brand text-white text-sm" role="region" aria-label="Breaking news"><div className="max-w-6xl mx-auto px-4 py-1 overflow-x-auto whitespace-nowrap"><b className="mr-3">BREAKING</b>{breaking.map(b => <Link key={b.id} to={`/news/${b.slug}`} className="mr-6 underline-offset-2 hover:underline">{b.headline}</Link>)}</div></div>}
      <main className="flex-1 max-w-6xl w-full mx-auto px-4 py-6"><Outlet /></main>
      <Newsletter /><CookieBanner />
    </div>
  )
}
function Newsletter() {
  const [email, setEmail] = useState(''); const [msg, setMsg] = useState('')
  const sub = async (e: FormEvent) => { e.preventDefault(); const { error } = await supabase.from('newsletter_subscribers').insert({ email }); setMsg(error ? (error.code === '23505' ? 'You are already subscribed.' : 'Please enter a valid email.') : 'Thanks, you are subscribed.'); if (!error) setEmail('') }
  return <footer id="newsletter" className="bg-ink text-gray-200 mt-8"><div className="max-w-6xl mx-auto px-4 py-8 grid gap-4 md:grid-cols-2">
    <div><Logo light link={false} /><p className="text-sm mt-2">Breaking News. Trusted Stories. Global Perspectives.</p></div>
    <form onSubmit={sub} className="flex gap-2 items-start"><label className="sr-only" htmlFor="nl">Email</label><input id="nl" className="input text-ink" type="email" required value={email} onChange={e => setEmail(e.target.value)} placeholder="Newsletter email" /><button className="btn">Subscribe</button></form>
    {msg && <p role="status" className="text-sm md:col-span-2">{msg}</p>}</div></footer>
}
