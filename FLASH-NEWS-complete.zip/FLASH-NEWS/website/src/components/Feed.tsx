import { useEffect, useState } from 'react'
import { supabase } from '../lib/supabase'
import { ARTICLE_SELECT, Article } from '../lib/types'
import ArticleCard from './ArticleCard'
import { useAutoRefresh } from '../lib/useAutoRefresh'
const PAGE = 12
interface Props { categorySlug?: string; tagSlug?: string; query?: string; authorId?: string; from?: string }
export default function Feed({ categorySlug, tagSlug, query, authorId, from }: Props) {
  const [items, setItems] = useState<Article[]>([]); const [page, setPage] = useState(0)
  const [tick, setTick] = useState(0); const [more, setMore] = useState(false); const [state, setState] = useState<'loading'|'ready'|'error'>('loading')
  useAutoRefresh(() => setTick(t => t + 1))
  useEffect(() => { setItems([]); setPage(0) }, [categorySlug, tagSlug, query, authorId, from])
  useEffect(() => {
    let live = true; setState('loading')
    let sel = categorySlug ? ARTICLE_SELECT.replace('categories(', 'categories!inner(') : ARTICLE_SELECT
    if (tagSlug) sel += ', article_tags!inner(tags!inner(slug))'
    let q = supabase.from('articles').select(sel)
      .in('status', ['published', 'scheduled']).order('published_at', { ascending: false }).range(page * PAGE, page * PAGE + PAGE)
    if (categorySlug) q = q.eq('categories.slug', categorySlug)
    if (tagSlug) q = q.eq('article_tags.tags.slug', tagSlug)
    if (authorId) q = q.eq('author_id', authorId)
    if (from) q = q.gte('published_at', from)
    if (query) q = q.textSearch('search', query, { type: 'websearch', config: 'english' })
    q.then(({ data, error }) => {
      if (!live) return
      if (error) { setState('error'); return }
      const rows = (data ?? []) as unknown as Article[]
      setMore(rows.length > PAGE); setItems(p => page === 0 ? rows.slice(0, PAGE) : [...p, ...rows.slice(0, PAGE)]); setState('ready')
    })
    return () => { live = false }
  }, [categorySlug, tagSlug, query, authorId, from, page, page === 0 ? tick : -1])
  if (state === 'error') return <p className="text-brand">Could not load stories. Please try again.</p>
  if (state === 'loading' && !items.length) return <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">{[1,2,3].map(i => <div key={i} className="h-56 animate-pulse bg-soft dark:bg-gray-800 rounded" />)}</div>
  if (!items.length) return <p className="text-gray-500">No published stories here yet.</p>
  return <><div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">{items.map(a => <ArticleCard key={a.id} a={a} />)}</div>
    {more && <div className="text-center mt-6"><button className="btn btn-ghost" onClick={() => setPage(p => p + 1)}>Load more</button></div>}</>
}
