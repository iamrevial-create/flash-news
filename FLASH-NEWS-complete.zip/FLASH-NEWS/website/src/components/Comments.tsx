import { useEffect, useState, FormEvent, useCallback } from 'react'
import { Link } from 'react-router-dom'
import { supabase } from '../lib/supabase'
import { useAuth } from '../lib/auth'
import { timeAgo } from '../lib/util'
interface C { id: string; body: string; approved: boolean; created_at: string; user_id: string; profiles: { display_name: string } | null }
export default function Comments({ articleId }: { articleId: string }) {
  const { session } = useAuth(); const [rows, setRows] = useState<C[]>([]); const [text, setText] = useState(''); const [msg, setMsg] = useState(''); const [busy, setBusy] = useState(false)
  const load = useCallback(() => { supabase.from('comments').select('id,body,approved,created_at,user_id,profiles(display_name)').eq('article_id', articleId).order('created_at').then(({ data }) => setRows((data ?? []) as unknown as C[])) }, [articleId])
  useEffect(load, [load])
  const submit = async (e: FormEvent) => {
    e.preventDefault(); if (!session || busy || !text.trim()) return; setBusy(true)
    const { error } = await supabase.from('comments').insert({ article_id: articleId, user_id: session.user.id, body: text.trim().slice(0, 2000) })
    setBusy(false); if (error) return setMsg('Could not post your comment.'); setText(''); setMsg('Thanks. Your comment will appear after moderation.'); load()
  }
  const del = async (id: string) => { await supabase.from('comments').delete().eq('id', id); load() }
  const flag = async (id: string) => { await supabase.from('comments').update({ reported: true }).eq('id', id); setMsg('Comment reported to moderators.') }
  return <section className="mt-10" aria-labelledby="cm"><h2 id="cm" className="text-xl font-bold mb-3">Comments</h2>
    {rows.length === 0 && <p className="text-sm text-gray-500">No comments yet.</p>}
    <ul className="space-y-3">{rows.map(c => <li key={c.id} className="p-3 border rounded dark:border-gray-700"><div className="text-xs text-gray-500">{c.profiles?.display_name ?? 'Reader'} · {timeAgo(c.created_at)}{!c.approved && ' · awaiting moderation'}</div><p className="text-sm whitespace-pre-wrap">{c.body}</p>
      <div className="text-xs mt-1 flex gap-3">{session?.user.id === c.user_id && <button className="underline" onClick={() => del(c.id)}>Delete</button>}{session && session.user.id !== c.user_id && c.approved && <button className="underline" onClick={() => flag(c.id)}>Report</button>}</div></li>)}</ul>
    {session ? <form onSubmit={submit} className="mt-4 space-y-2"><label className="label" htmlFor="ct">Add a comment (reviewed before it appears)</label><textarea id="ct" className="input" rows={3} maxLength={2000} value={text} onChange={e => setText(e.target.value)} /><button className="btn" disabled={busy}>Post comment</button></form>
      : <p className="mt-3 text-sm"><Link className="underline" to="/sign-in">Sign in</Link> to comment.</p>}
    {msg && <p role="status" className="text-sm mt-2">{msg}</p>}</section>
}
