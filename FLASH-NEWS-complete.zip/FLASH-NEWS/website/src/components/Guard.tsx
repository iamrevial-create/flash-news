import { ReactNode } from 'react'
import { Navigate } from 'react-router-dom'
import { useAuth } from '../lib/auth'
import type { Role } from '../lib/types'
// UI convenience only: real enforcement is Row Level Security and triggers in the database.
export function Guard({ roles, children }: { roles: Role[]; children: ReactNode }) {
  const { session, profile, loading } = useAuth()
  if (loading) return <p className="p-8">Loading…</p>
  if (!session) return <Navigate to="/sign-in" replace />
  if (!profile || profile.status === 'suspended' || !roles.includes(profile.role))
    return <div className="max-w-xl mx-auto p-8"><h1 className="text-xl font-bold">Access restricted</h1><p>Your account does not have access to this area.</p></div>
  return <>{children}</>
}
