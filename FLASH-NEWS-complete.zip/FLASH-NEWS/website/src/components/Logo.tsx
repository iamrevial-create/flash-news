import { Link } from 'react-router-dom'
// FLASH NEWS wordmark: skewed red "FLASH" block + "NEWS" (matches the original published design).
export default function Logo({ size = 24, light = false, link = true }: { size?: number; light?: boolean; link?: boolean }) {
  const inner = <span style={{ font: `900 ${size}px system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif`, letterSpacing: '-.5px', lineHeight: 1.2, display: 'inline-block', whiteSpace: 'nowrap' }} className={light ? 'text-white' : ''}>
    <b style={{ background: '#D71920', color: '#fff', padding: '0 7px', marginRight: 4, transform: 'skew(-8deg)', display: 'inline-block' }}>FLASH</b>NEWS</span>
  return link ? <Link to="/" aria-label="FLASH NEWS home">{inner}</Link> : inner
}
