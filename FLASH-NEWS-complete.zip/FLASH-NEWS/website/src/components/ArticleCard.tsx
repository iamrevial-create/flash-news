import { Link } from 'react-router-dom'
import type { Article } from '../lib/types'
import { timeAgo } from '../lib/util'
export function Img({ a, className = '' }: { a: Article; className?: string }) {
  return a.featured_image_url
    ? <img src={a.featured_image_url} alt={a.image_alt || a.headline} loading="lazy" className={`w-full aspect-video object-cover bg-soft ${className}`} />
    : <div role="img" aria-label="No image" className={`w-full aspect-video bg-gradient-to-br from-brand to-ink grid place-items-center text-white font-black text-xl ${className}`}>FLASH</div>
}
export default function ArticleCard({ a }: { a: Article }) {
  return (
    <article className="border-b border-gray-200 dark:border-gray-700 pb-3">
      <Link to={`/news/${a.slug}`}><Img a={a} /><div className="tag mt-2">{a.categories?.name}{a.is_sponsored && ' · Sponsored'}</div><h3 className="font-serif text-lg leading-snug font-bold my-1">{a.headline}</h3></Link>
      {a.summary && <p className="text-sm text-gray-600 dark:text-gray-400">{a.summary}</p>}
      <p className="text-xs text-gray-500 mt-1">{a.byline || a.profiles?.display_name} · {timeAgo(a.published_at)}</p>
    </article>
  )
}
