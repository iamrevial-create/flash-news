import { Routes, Route } from 'react-router-dom'
import Layout from './components/Layout'
import { Guard } from './components/Guard'
import Home from './pages/Home'
import Category from './pages/Category'
import ArticlePage from './pages/ArticlePage'
import Search from './pages/Search'
import SignIn from './pages/SignIn'
import BecomePublisher from './pages/BecomePublisher'
import Dashboard from './pages/Dashboard'
import MyArticles from './pages/MyArticles'
import ArticleForm from './pages/ArticleForm'
import EditorQueue from './pages/EditorQueue'
import Admin from './pages/Admin'
import PublisherProfile from './pages/PublisherProfile'
import MediaLibrary from './pages/MediaLibrary'
import TagPage from './pages/TagPage'
import Saved from './pages/Saved'
import Notifications from './pages/Notifications'
import { configured } from './lib/supabase'
export default function App() {
  if (!configured) return <div className="p-8 max-w-xl mx-auto"><h1 className="text-2xl font-bold">Setup needed</h1><p>Copy <code>.env.example</code> to <code>.env</code> and set VITE_SUPABASE_URL and VITE_SUPABASE_PUBLISHABLE_KEY.</p></div>
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route index element={<Home />} />
        <Route path="category/:slug" element={<Category />} />
        <Route path="news/:slug" element={<ArticlePage />} />
        <Route path="tag/:slug" element={<TagPage />} />
        <Route path="saved" element={<Guard roles={['reader','applicant','publisher','reporter','editor','admin']}><Saved /></Guard>} />
        <Route path="notifications" element={<Guard roles={['reader','applicant','publisher','reporter','editor','admin']}><Notifications /></Guard>} />
        <Route path="search" element={<Search />} />
        <Route path="sign-in" element={<SignIn />} />
        <Route path="become-a-publisher" element={<BecomePublisher />} />
        <Route path="publishers/:slug" element={<PublisherProfile />} />
        <Route path="publisher/dashboard" element={<Guard roles={['publisher','reporter','editor','admin']}><Dashboard /></Guard>} />
        <Route path="publisher/media" element={<Guard roles={['publisher','reporter','editor','admin']}><MediaLibrary /></Guard>} />
        <Route path="publisher/articles" element={<Guard roles={['publisher','reporter','editor','admin']}><MyArticles /></Guard>} />
        <Route path="publisher/articles/new" element={<Guard roles={['publisher','reporter','editor','admin']}><ArticleForm /></Guard>} />
        <Route path="publisher/articles/:id/edit" element={<Guard roles={['publisher','reporter','editor','admin']}><ArticleForm /></Guard>} />
        <Route path="editor" element={<Guard roles={['editor','admin']}><EditorQueue /></Guard>} />
        <Route path="admin" element={<Guard roles={['admin']}><Admin /></Guard>} />
        <Route path="*" element={<p className="p-8">Page not found.</p>} />
      </Route>
    </Routes>
  )
}
