import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { supabase } from '../lib/supabase'
import { timeAgo } from '../lib/util'
import { useAutoRefresh } from '../lib/useAutoRefresh'

interface N { id: string; title: string; body: string | null; link: string | null; read: boolean; created_at: string }
export default function Notifications() {
  const [rows, setRows] = useState<N[]>([])
  useAutoRefresh(() => { supabase.from('notifications').select('*').order('created_at', { ascending: false }).limit(50).then(({ data }) => setRows((data ?? []) as N[])) })
  const markAll = async () => { await supabase.from('notifications').update({ read: true }).eq('read', false); setRows(rows.map(r => ({ ...r, read: true }))) }
  return <><div className="flex justify-between mb-4"><h1 className="text-2xl font-black">Notifications</h1><button className="btn btn-ghost" onClick={markAll}>Mark all read</button></div>
    {!rows.length && <p className="text-gray-500">No notifications.</p>}
    {rows.map(n => <div key={n.id} className={`p-3 border-b dark:border-gray-700 ${n.read ? '' : 'bg-soft dark:bg-gray-800'}`}><b>{n.title}</b> <span className="text-xs text-gray-500">{timeAgo(n.created_at)}</span>{n.body && <p className="text-sm">{n.body}</p>}{n.link && <Link className="text-sm underline" to={n.link.startsWith('/publisher/articles/') ? '/publisher/articles' : n.link}>Open</Link>}</div>)}</>
}
