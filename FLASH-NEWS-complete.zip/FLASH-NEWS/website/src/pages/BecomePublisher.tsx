import { useEffect, useState, FormEvent } from 'react'
import { Link } from 'react-router-dom'
import { supabase } from '../lib/supabase'
import { useAuth } from '../lib/auth'
import { isHttpUrl } from '../lib/util'
interface App { status: string; decision_reason: string | null }
export default function BecomePublisher() {
  const { session, profile } = useAuth(); const [app, setApp] = useState<App | null>(null); const [err, setErr] = useState(''); const [busy, setBusy] = useState(false)
  const [f, setF] = useState({ publication_name: '', bio: '', country: 'Nigeria', location: '', interests: '', website: '', agreed: false })
  const load = () => session && supabase.from('publisher_applications').select('status,decision_reason').eq('user_id', session.user.id).order('created_at', { ascending: false }).limit(1).then(({ data }) => setApp((data?.[0] as App) ?? null))
  useEffect(() => { load() }, [session])
  if (!session) return <div className="max-w-xl mx-auto"><h1 className="text-3xl font-black">Become a Publisher</h1><p className="my-3">Create a free reader account first, verify your email, then apply here.</p><Link to="/sign-in" className="btn">Sign in or create account</Link></div>
  if (profile && profile.role !== 'reader' && profile.role !== 'applicant') return <p>You already have publishing access. <Link className="underline" to="/publisher/dashboard">Open dashboard</Link></p>
  if (app && (app.status === 'pending' || app.status === 'info_requested' || app.status === 'rejected')) return <div className="max-w-xl mx-auto"><h1 className="text-2xl font-black">Application {app.status.replace('_', ' ')}</h1>{app.decision_reason && <p className="my-2 p-3 bg-soft dark:bg-gray-800 rounded">Editor note: {app.decision_reason}</p>}<p>Publishing access is granted only after editors approve your application.</p></div>
  const submit = async (e: FormEvent) => {
    e.preventDefault(); setErr('')
    if (f.bio.trim().length < 50) return setErr('Please write a biography of at least 50 characters.')
    if (f.website && !isHttpUrl(f.website)) return setErr('Website must start with http:// or https://')
    if (!f.agreed) return setErr('You must accept the publisher agreement and editorial policy.')
    setBusy(true)
    const { error } = await supabase.from('publisher_applications').insert({ user_id: session.user.id, publication_name: f.publication_name.trim(), bio: f.bio.trim(), country: f.country, location: f.location || null, website: f.website || null, interests: f.interests.split(',').map(s => s.trim()).filter(Boolean), agreed_policy: true })
    setBusy(false); if (error) setErr(error.code === '23505' ? 'You already have an open application.' : error.message); else load()
  }
  const set = (k: string, v: string | boolean) => setF({ ...f, [k]: v })
  return <form onSubmit={submit} className="max-w-xl mx-auto space-y-3"><h1 className="text-3xl font-black">Become a Publisher</h1><p className="text-sm text-gray-600 dark:text-gray-400">Applications are reviewed by our editors. Approval is required before you can submit stories, and every story is reviewed before it is published.</p>
    <div><label className="label" htmlFor="pn">Publication or display name</label><input id="pn" className="input" required value={f.publication_name} onChange={e => set('publication_name', e.target.value)} /></div>
    <div><label className="label" htmlFor="b">Professional biography</label><textarea id="b" className="input" rows={5} required value={f.bio} onChange={e => set('bio', e.target.value)} /></div>
    <div className="grid grid-cols-2 gap-3"><div><label className="label" htmlFor="c">Country</label><input id="c" className="input" value={f.country} onChange={e => set('country', e.target.value)} /></div><div><label className="label" htmlFor="l">Location (optional)</label><input id="l" className="input" value={f.location} onChange={e => set('location', e.target.value)} /></div></div>
    <div><label className="label" htmlFor="i">Reporting interests (comma separated)</label><input id="i" className="input" value={f.interests} onChange={e => set('interests', e.target.value)} /></div>
    <div><label className="label" htmlFor="w">Website or portfolio (optional)</label><input id="w" className="input" value={f.website} onChange={e => set('website', e.target.value)} /></div>
    <label className="flex gap-2 text-sm"><input type="checkbox" checked={f.agreed} onChange={e => set('agreed', e.target.checked)} /> I accept the publisher agreement and editorial policy.</label>
    {err && <p role="alert" className="text-brand text-sm">{err}</p>}<button className="btn" disabled={busy}>Submit application</button></form>
}
