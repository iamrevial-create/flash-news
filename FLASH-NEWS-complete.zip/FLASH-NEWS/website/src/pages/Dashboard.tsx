import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { supabase } from '../lib/supabase'
import { useAuth } from '../lib/auth'
import type { Article } from '../lib/types'
import Earnings from '../components/Earnings'
import { useAutoRefresh } from '../lib/useAutoRefresh'

export default function Dashboard() {
  const { session, profile } = useAuth(); const [rows, setRows] = useState<Article[]>([]); const [notes, setNotes] = useState<{ id: string; title: string; body: string | null }[]>([]); const [views, setViews] = useState(0); const [wa, setWa] = useState('')
  useAutoRefresh(() => { if (!session) return
    supabase.from('articles').select('id,headline,slug,status,review_note,updated_at').eq('author_id', session.user.id).then(({ data }) => setRows((data ?? []) as Article[]))
    supabase.from('notifications').select('id,title,body').order('created_at', { ascending: false }).limit(5).then(({ data }) => setNotes(data ?? []))
    supabase.from('site_settings').select('value').eq('key', 'public.whatsapp_group').maybeSingle().then(({ data }) => setWa(((data?.value as { url?: string })?.url) ?? ''))
    supabase.from('article_analytics').select('views').then(({ data }) => setViews((data ?? []).reduce((s, r) => s + Number(r.views), 0))) }, 15000, [session?.user.id])
  const n = (s: string) => rows.filter(r => r.status === s).length
  const tiles: [string, number][] = [['Published', n('published')], ['Drafts', n('draft')], ['Awaiting review', n('submitted') + n('in_review')], ['Changes requested', n('changes_requested')], ['Rejected', n('rejected')], ['Total views', views]]
  return <><h1 className="text-3xl font-black">Welcome, {profile?.display_name}</h1>
    <div className="flex gap-2 my-4 flex-wrap"><Link className="btn" to="/publisher/articles/new">Write a story</Link><Link className="btn btn-ghost" to="/publisher/articles">My articles</Link><Link className="btn btn-ghost" to="/publisher/media">Photos &amp; videos</Link>{/^https:\/\/(chat\.whatsapp\.com|wa\.me)\//.test(wa) && <a className="btn btn-ghost" href={wa} target="_blank" rel="noopener">Publishers WhatsApp group</a>}{profile?.slug && <Link className="btn btn-ghost" to={`/publishers/${profile.slug}`}>Public profile</Link>}</div>
    <div className="grid grid-cols-2 md:grid-cols-3 gap-3">{tiles.map(([l, v]) => <div key={l} className="p-4 bg-soft dark:bg-gray-800 rounded"><div className="text-3xl font-black">{v}</div><div className="text-sm">{l}</div></div>)}</div>
    <Earnings /><h2 className="font-bold text-lg mt-6 mb-2">Editorial notifications</h2>{notes.length ? <ul className="space-y-2">{notes.map(x => <li key={x.id} className="p-3 border rounded dark:border-gray-700"><b>{x.title}</b>{x.body && <p className="text-sm">{x.body}</p>}</li>)}</ul> : <p className="text-gray-500 text-sm">Nothing yet.</p>}</>
}
