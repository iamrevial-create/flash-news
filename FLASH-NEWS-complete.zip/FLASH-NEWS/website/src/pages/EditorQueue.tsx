import { useEffect, useState, useCallback } from 'react'
import { Link } from 'react-router-dom'
import { supabase } from '../lib/supabase'
import { ARTICLE_SELECT, Article } from '../lib/types'
import { timeAgo } from '../lib/util'
import { useAutoRefresh } from '../lib/useAutoRefresh'
import { Apps, CommentMod, Reports } from './Admin'
import Earnings from '../components/Earnings'
function Queue() {
  const [rows, setRows] = useState<Article[]>([]); const [open, setOpen] = useState<string | null>(null); const [note, setNote] = useState(''); const [when, setWhen] = useState(''); const [msg, setMsg] = useState('')
  const [revs, setRevs] = useState<{ version: number; created_at: string }[]>([])
  const load = useCallback(() => { supabase.from('articles').select(ARTICLE_SELECT).in('status', ['submitted', 'in_review', 'approved', 'scheduled']).order('submitted_at').then(({ data }) => setRows((data ?? []) as unknown as Article[])) }, [])
  useAutoRefresh(load)
  useEffect(() => { if (open) supabase.from('article_revisions').select('version,created_at').eq('article_id', open).order('version').then(({ data }) => setRevs(data ?? [])) }, [open])
  const act = async (a: Article, status: string, extra: Record<string, unknown> = {}) => {
    setMsg(''); const { error } = await supabase.from('articles').update({ status, review_note: note || null, ...extra }).eq('id', a.id)
    if (error) return setMsg(error.message); setNote(''); setWhen(''); setOpen(null); load()
  }
  const flag = async (a: Article, k: 'is_breaking' | 'is_featured') => { const { error } = await supabase.from('articles').update({ [k]: !a[k] }).eq('id', a.id); error ? setMsg(error.message) : load() }
  return <><h1 className="text-2xl font-black mb-4">Editorial queue</h1>{msg && <p role="alert" className="text-brand mb-3">{msg}</p>}
    {!rows.length && <p className="text-gray-500">The queue is empty.</p>}
    {rows.map(a => <div key={a.id} className="border dark:border-gray-700 rounded p-3 mb-3">
      <div className="flex justify-between gap-3 flex-wrap"><div><button className="font-bold text-left" onClick={() => setOpen(open === a.id ? null : a.id)}>{a.headline}</button><div className="text-xs text-gray-500">{a.categories?.name} · {a.content_type.replace('_', ' ')} · by {a.profiles?.display_name} · submitted {timeAgo(a.submitted_at)}</div></div><span className="text-xs bg-soft dark:bg-gray-800 px-2 py-1 rounded h-fit">{a.status.replace('_', ' ')}</span></div>
      {open === a.id && <div className="mt-3 space-y-3"><p className="text-sm italic">{a.summary}</p><div className="max-h-72 overflow-auto text-sm whitespace-pre-wrap bg-soft dark:bg-gray-800 p-3 rounded">{a.body}</div>
        <p className="text-xs text-gray-500">Revisions on record: {revs.length}. <Link className="underline" to={`/news/${a.slug}`}>Preview as page</Link></p>
        <div><label className="label" htmlFor={`n${a.id}`}>Editor note (required to reject or request changes)</label><textarea id={`n${a.id}`} className="input" rows={3} value={note} onChange={e => setNote(e.target.value)} /></div>
        <div className="flex gap-2 flex-wrap items-center"><button className="btn" onClick={() => act(a, 'published')}>Approve &amp; publish</button><button className="btn btn-ghost" onClick={() => act(a, 'changes_requested')}>Request changes</button><button className="btn btn-ghost" onClick={() => act(a, 'rejected')}>Reject</button>
          <input type="datetime-local" aria-label="Schedule time" className="input !w-auto" value={when} onChange={e => setWhen(e.target.value)} /><button className="btn btn-ghost" disabled={!when} onClick={() => act(a, 'scheduled', { scheduled_at: new Date(when).toISOString() })}>Schedule</button></div></div>}
    </div>)}
    <h2 className="text-lg font-bold mt-8 mb-2">Placement controls (published stories)</h2><Placement onFlag={flag} /></>
}
function Placement({ onFlag }: { onFlag: (a: Article, k: 'is_breaking' | 'is_featured') => void }) {
  const [rows, setRows] = useState<Article[]>([]); useEffect(() => { supabase.from('articles').select('id,headline,is_breaking,is_featured').eq('status', 'published').order('published_at', { ascending: false }).limit(15).then(({ data }) => setRows((data ?? []) as Article[])) }, [])
  return <>{rows.map(a => <div key={a.id} className="flex justify-between py-2 border-b dark:border-gray-700 text-sm gap-2"><span>{a.headline}</span><span className="flex gap-2 shrink-0"><button className="btn btn-ghost" onClick={() => { onFlag(a, 'is_breaking'); setRows(rows.map(r => r.id === a.id ? { ...r, is_breaking: !r.is_breaking } : r)) }}>{a.is_breaking ? 'Remove breaking' : 'Mark breaking'}</button><button className="btn btn-ghost" onClick={() => { onFlag(a, 'is_featured'); setRows(rows.map(r => r.id === a.id ? { ...r, is_featured: !r.is_featured } : r)) }}>{a.is_featured ? 'Unfeature' : 'Feature'}</button></span></div>)}</>
}

export default function EditorQueue() {
  const [tab, setTab] = useState('queue')
  return <><div className="flex gap-2 mb-4 flex-wrap">{[['queue', 'Review queue'], ['apps', 'Publisher applications'], ['comments', 'Comments'], ['reports', 'Reports'], ['earn', 'My earnings']].map(([k, l]) => <button key={k} className={`btn ${tab === k ? '' : 'btn-ghost'}`} onClick={() => setTab(k)}>{l}</button>)}</div>
    {tab === 'queue' && <Queue />}{tab === 'apps' && <Apps />}{tab === 'comments' && <CommentMod />}{tab === 'reports' && <Reports />}{tab === 'earn' && <Earnings />}</>
}
