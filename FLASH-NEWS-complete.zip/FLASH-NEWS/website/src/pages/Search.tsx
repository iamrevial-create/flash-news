import { useSearchParams } from 'react-router-dom'
import Feed from '../components/Feed'
export default function Search() {
  const [p] = useSearchParams(); const q = p.get('q') ?? ''
  return <><h1 className="text-2xl font-black mb-4">Results for “{q}”</h1>{q ? <Feed query={q} /> : <p>Type something in the search box.</p>}</>
}
