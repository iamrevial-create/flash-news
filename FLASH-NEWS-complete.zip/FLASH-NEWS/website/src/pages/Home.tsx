import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { supabase } from '../lib/supabase'
import { ARTICLE_SELECT, Article } from '../lib/types'
import ArticleCard, { Img } from '../components/ArticleCard'
import Feed from '../components/Feed'
import { timeAgo } from '../lib/util'
import { useAutoRefresh } from '../lib/useAutoRefresh'
export default function Home() {
  const [top, setTop] = useState<Article[] | null>(null); const [ad, setAd] = useState<{ image_url: string; link: string; alt: string } | null>(null)
  useEffect(() => { supabase.from('site_settings').select('value').eq('key', 'public.ad_banner').maybeSingle().then(({ data }) => { const v = data?.value as { image_url: string; link: string; alt: string } | undefined; setAd(v && /^https:\/\//.test(v.image_url) && /^https:\/\//.test(v.link) ? v : null) }) }, [])
  useEffect(() => { document.title = 'FLASH NEWS — Breaking News. Trusted Stories.' }, [])
  useAutoRefresh(() => { supabase.from('articles').select(ARTICLE_SELECT).in('status', ['published', 'scheduled'])
    .order('is_featured', { ascending: false }).order('published_at', { ascending: false }).limit(4).then(({ data }) => setTop((data ?? []) as unknown as Article[])) })
  if (top && !top.length) return <div className="py-16 text-center"><h1 className="text-3xl font-black">No stories published yet</h1><p className="mt-2 text-gray-500">Approved publishers can submit stories and editors publish them here.</p><Link to="/become-a-publisher" className="btn mt-4">Become a Publisher</Link></div>
  const [lead, ...rest] = top ?? []
  return <>
    {lead && <section className="grid gap-6 lg:grid-cols-3 mb-8"><Link to={`/news/${lead.slug}`} className="lg:col-span-2"><Img a={lead} /><div className="tag mt-3">{lead.categories?.name}</div><h1 className="font-serif text-3xl md:text-4xl font-black leading-tight">{lead.headline}</h1><p className="text-gray-600 dark:text-gray-400 mt-1">{lead.summary}</p><p className="text-xs text-gray-500 mt-1">{lead.byline || lead.profiles?.display_name} · {timeAgo(lead.published_at)}</p></Link>
      <div className="grid gap-4 content-start">{rest.map(a => <ArticleCard key={a.id} a={a} />)}</div></section>}
    {ad && <aside aria-label="Advertisement" className="mb-6"><p className="text-[10px] uppercase tracking-wider text-gray-500 mb-1">Advertisement</p><a href={ad.link} target="_blank" rel="noopener sponsored nofollow"><img src={ad.image_url} alt={ad.alt || 'Advertisement'} loading="lazy" className="w-full max-h-40 object-cover rounded" /></a></aside>}
    <h2 className="tag text-sm border-b-2 border-brand pb-1 mb-4">Latest news</h2><Feed />
  </>
}
