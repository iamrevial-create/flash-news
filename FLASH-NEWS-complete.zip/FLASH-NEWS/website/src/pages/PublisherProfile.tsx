import { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom'
import { supabase } from '../lib/supabase'
import type { Profile } from '../lib/types'
import Feed from '../components/Feed'
export default function PublisherProfile() {
  const { slug } = useParams(); const [p, setP] = useState<Profile | null | undefined>()
  useEffect(() => { supabase.from('profiles').select('*').eq('slug', slug).maybeSingle().then(({ data }) => setP((data as Profile) ?? null)) }, [slug])
  if (p === undefined) return <p>Loading…</p>
  if (!p) return <p>Publisher not found.</p>
  return <><div className="flex gap-4 items-center mb-6">{p.avatar_url && <img src={p.avatar_url} alt="" className="w-20 h-20 rounded-full object-cover" />}
    <div><h1 className="text-3xl font-black">{p.display_name}{p.verified && <span className="ml-2 text-sm bg-brand text-white px-2 py-0.5 rounded" title="Verified by FLASH NEWS editors">Verified</span>}</h1><p className="text-gray-600 dark:text-gray-400">{p.bio}</p>
    {p.website && <a className="underline text-sm" href={p.website} rel="noopener nofollow ugc" target="_blank">Website</a>}</div></div><Feed authorId={p.id} /></>
}
