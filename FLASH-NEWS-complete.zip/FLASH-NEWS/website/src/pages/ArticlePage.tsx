import { useEffect, useState } from 'react'
import { useParams, Link } from 'react-router-dom'
import { supabase } from '../lib/supabase'
import { ARTICLE_SELECT, Article } from '../lib/types'
import { useAuth } from '../lib/auth'
import { Img } from '../components/ArticleCard'
import { readingTime, isHttpUrl, toEmbed } from '../lib/util'
import { MEDIA_BASE } from '../lib/media'
import Comments from '../components/Comments'
interface Src { id: string; label: string | null; url: string | null }
export default function ArticlePage() {
  const { slug } = useParams(); const { session } = useAuth()
  const [a, setA] = useState<Article | null | undefined>(); const [src, setSrc] = useState<Src[]>([]); const [saved, setSaved] = useState(false)
  const [nb, setNb] = useState<{ prev?: Article; next?: Article }>({}); const [note, setNote] = useState(''); const [tags, setTags] = useState<{ name: string; slug: string }[]>([])
  useEffect(() => {
    setA(undefined)
    supabase.from('articles').select(ARTICLE_SELECT).eq('slug', slug).maybeSingle().then(async ({ data }) => {
      const art = data as unknown as Article | null; setA(art); if (!art) return
      document.title = `${art.headline} — FLASH NEWS`
      setMeta('description', art.summary ?? ''); setMeta('og:title', art.headline); setMeta('og:description', art.summary ?? ''); if (art.featured_image_url) setMeta('og:image', art.featured_image_url)
      supabase.from('article_sources').select('id,label,url').eq('article_id', art.id).then(r => setSrc((r.data ?? []) as Src[]))
      supabase.from('article_tags').select('tags(name,slug)').eq('article_id', art.id).then(r => setTags((r.data ?? []).map((x: any) => x.tags).filter(Boolean)))
      if (art.status === 'published') {
        const k = `fn-viewed-${art.id}`; if (!sessionStorage.getItem(k)) { sessionStorage.setItem(k, '1'); supabase.rpc('increment_view', { aid: art.id }).then(() => {}) }
        const base = () => supabase.from('articles').select('slug,headline,published_at').eq('status', 'published').neq('id', art.id)
        const [p, n] = await Promise.all([base().lt('published_at', art.published_at!).order('published_at', { ascending: false }).limit(1), base().gt('published_at', art.published_at!).order('published_at').limit(1)])
        setNb({ prev: (p.data?.[0] as Article) , next: (n.data?.[0] as Article) })
      }
      if (session) supabase.from('bookmarks').select('article_id').eq('article_id', art.id).eq('user_id', session.user.id).maybeSingle().then(r => setSaved(!!r.data))
    })
  }, [slug, session])
  if (a === undefined) return <div className="h-64 animate-pulse bg-soft dark:bg-gray-800 rounded" />
  if (!a) return <p>Article not found, or it is not public.</p>
  const toggle = async () => { if (!session) return setNote('Sign in to save stories.'); if (saved) await supabase.from('bookmarks').delete().eq('article_id', a.id).eq('user_id', session.user.id); else await supabase.from('bookmarks').insert({ article_id: a.id, user_id: session.user.id }); setSaved(!saved) }
  const report = async () => { if (!session) return setNote('Sign in to report an issue.'); const reason = prompt('What is wrong with this article?'); if (reason?.trim()) { const { error } = await supabase.from('reports').insert({ article_id: a.id, reporter_id: session.user.id, reason }); setNote(error ? 'Could not send report.' : 'Thanks, our editors will review it.') } }
  const updated = a.published_at && new Date(a.updated_at).getTime() - new Date(a.published_at).getTime() > 60000
  const ld = { '@context': 'https://schema.org', '@type': 'NewsArticle', headline: a.headline, datePublished: a.published_at, dateModified: a.updated_at, author: { '@type': 'Person', name: a.byline || a.profiles?.display_name }, image: a.featured_image_url ? [a.featured_image_url] : undefined, publisher: { '@type': 'Organization', name: 'FLASH NEWS' } }
  const url = window.location.href
  return (
    <article className="max-w-3xl mx-auto">
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(ld).replace(/</g, '\\u003c') }} />
      {a.status !== 'published' && <div className="bg-soft dark:bg-gray-800 p-3 rounded mb-4 text-sm">Status: <b>{a.status.replace('_', ' ')}</b>. This story is not public yet.</div>}
      <div className="tag">{a.categories?.name}{a.content_type !== 'original_reporting' && ` · ${a.content_type.replace('_', ' ')}`}{a.is_sponsored && ' · Sponsored content'}</div>
      <h1 className="font-serif text-3xl md:text-5xl font-black leading-tight my-2">{a.headline}</h1>
      {a.subheadline && <p className="text-xl text-gray-600 dark:text-gray-400">{a.subheadline}</p>}
      <p className="text-sm text-gray-500 my-3">By {a.profiles?.slug ? <Link className="underline" to={`/publishers/${a.profiles.slug}`}>{a.byline || a.profiles.display_name}</Link> : (a.byline || a.profiles?.display_name)}{a.profiles?.verified && ' ✓'} · Published {a.published_at ? new Date(a.published_at).toLocaleString() : '—'}{updated && ` · Updated ${new Date(a.updated_at).toLocaleString()}`} · {readingTime(a.body)} min read</p>
      <Img a={a} />{a.image_caption && <p className="text-xs text-gray-500 mt-1">{a.image_caption}</p>}
      {(() => { const v = a.video_url ? toEmbed(a.video_url, MEDIA_BASE) : null; return v ? <div className="mt-6">{v.kind === 'file' ? <video src={v.src} controls preload="metadata" className="w-full aspect-video bg-black rounded" /> : <iframe src={v.src} title="Video report" className="w-full aspect-video rounded" allow="fullscreen; picture-in-picture" allowFullScreen loading="lazy" referrerPolicy="strict-origin-when-cross-origin" />}</div> : null })()}
      <div className="font-serif text-lg leading-8 mt-6 space-y-4">{a.body.split(/\n{2,}/).map((p, i) => p.startsWith('## ') ? <h2 key={i} className="font-sans font-bold text-2xl">{p.slice(3)}</h2> : p.startsWith('> ') ? <blockquote key={i} className="border-l-4 border-brand pl-4 italic">{p.slice(2)}</blockquote> : <p key={i}>{p}</p>)}</div>
      {tags.length > 0 && <p className="mt-4 text-sm">{tags.map(t => <Link key={t.slug} to={`/tag/${t.slug}`} className="inline-block mr-2 px-2 py-0.5 bg-soft dark:bg-gray-800 rounded">#{t.name}</Link>)}</p>}
      {(src.length > 0 || a.source_note) && <div className="mt-6 p-3 bg-soft dark:bg-gray-800 rounded text-sm"><b>Sources</b>{a.source_note && <p>{a.source_note}</p>}<ul className="list-disc ml-5">{src.map(s => <li key={s.id}>{s.url && isHttpUrl(s.url) ? <a className="underline" rel="noopener nofollow" target="_blank" href={s.url}>{s.label || s.url}</a> : s.label}</li>)}</ul></div>}
      <div className="flex flex-wrap gap-2 mt-6">
        <a className="btn" target="_blank" rel="noopener" href={`https://wa.me/?text=${encodeURIComponent(a.headline + ' ' + url)}`}>WhatsApp</a>
        <a className="btn btn-ghost" target="_blank" rel="noopener" href={`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}`}>Facebook</a>
        <a className="btn btn-ghost" target="_blank" rel="noopener" href={`https://twitter.com/intent/tweet?text=${encodeURIComponent(a.headline)}&url=${encodeURIComponent(url)}`}>X</a>
        <button className="btn btn-ghost" onClick={() => navigator.clipboard?.writeText(url).then(() => setNote('Link copied.'))}>Copy link</button>
        <button className="btn btn-ghost" onClick={toggle}>{saved ? '★ Saved' : '☆ Save'}</button>
        <button className="btn btn-ghost" onClick={report}>Report</button></div>
      {note && <p role="status" className="text-sm mt-2">{note}</p>}
      {a.status === 'published' && <Comments articleId={a.id} />}
      <nav className="flex justify-between mt-8 text-sm">{nb.prev ? <Link className="underline" to={`/news/${nb.prev.slug}`}>← {nb.prev.headline}</Link> : <span />}{nb.next && <Link className="underline text-right" to={`/news/${nb.next.slug}`}>{nb.next.headline} →</Link>}</nav>
    </article>
  )
}
function setMeta(name: string, content: string) {
  const attr = name.startsWith('og:') ? 'property' : 'name'
  let el = document.head.querySelector(`meta[${attr}="${name}"]`) as HTMLMetaElement | null
  if (!el) { el = document.createElement('meta'); el.setAttribute(attr, name); document.head.appendChild(el) }
  el.content = content
}
