import { useEffect, useState } from 'react'
import { supabase } from '../lib/supabase'
import { ARTICLE_SELECT, Article } from '../lib/types'
import ArticleCard from '../components/ArticleCard'
export default function Saved() {
  const [rows, setRows] = useState<Article[] | null>(null)
  useEffect(() => { supabase.from('bookmarks').select(`articles(${ARTICLE_SELECT})`).order('created_at', { ascending: false }).then(({ data }) => setRows((data ?? []).map((r: any) => r.articles).filter(Boolean))) }, [])
  return <><h1 className="text-2xl font-black mb-4">Saved stories</h1>{rows && !rows.length && <p className="text-gray-500">Nothing saved yet.</p>}<div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">{rows?.map(a => <ArticleCard key={a.id} a={a} />)}</div></>
}
