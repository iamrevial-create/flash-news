import { useEffect, useState } from 'react'
import { useParams, Link } from 'react-router-dom'
import { supabase } from '../lib/supabase'
import type { Category as Cat } from '../lib/types'
import Feed from '../components/Feed'
export default function Category() {
  const { slug } = useParams(); const [cat, setCat] = useState<Cat | null | undefined>(); const [days, setDays] = useState(''); const [others, setOthers] = useState<Cat[]>([])
  useEffect(() => { supabase.from('categories').select('*').order('sort').then(({ data }) => { const all = (data ?? []) as Cat[]; const c = all.find(x => x.slug === slug) ?? null; setCat(c); setOthers(all.filter(x => x.slug !== slug).slice(0, 5)); if (c) document.title = `${c.name} — FLASH NEWS` }) }, [slug])
  if (cat === null) return <p>Category not found.</p>
  const from = days ? new Date(Date.now() - Number(days) * 864e5).toISOString() : undefined
  return <><div className="flex items-end justify-between flex-wrap gap-2 mb-4 border-b-2 border-brand pb-2"><h1 className="text-3xl font-black">{cat?.name}</h1>
    <label className="text-sm">Date <select className="input !w-auto" value={days} onChange={e => setDays(e.target.value)}><option value="">All time</option><option value="1">Last 24 hours</option><option value="7">Last 7 days</option><option value="30">Last 30 days</option></select></label></div>
    <Feed categorySlug={slug} from={from} />
    <p className="mt-8 text-sm">Related: {others.map(o => <Link key={o.id} className="underline mr-3" to={`/category/${o.slug}`}>{o.name}</Link>)}</p></>
}
