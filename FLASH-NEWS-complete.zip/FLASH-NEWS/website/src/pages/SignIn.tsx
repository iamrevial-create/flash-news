import { useState, FormEvent } from 'react'
import { useNavigate } from 'react-router-dom'
import { supabase } from '../lib/supabase'
export default function SignIn() {
  const nav = useNavigate(); const [mode, setMode] = useState<'in' | 'up' | 'reset'>('in')
  const [email, setEmail] = useState(''); const [pw, setPw] = useState(''); const [name, setName] = useState(''); const [msg, setMsg] = useState(''); const [busy, setBusy] = useState(false)
  const submit = async (e: FormEvent) => {
    e.preventDefault(); setBusy(true); setMsg('')
    if (mode === 'in') { const { error } = await supabase.auth.signInWithPassword({ email, password: pw }); error ? setMsg(error.message) : nav('/') }
    else if (mode === 'up') { if (pw.length < 8) { setMsg('Use at least 8 characters.'); setBusy(false); return } const { error } = await supabase.auth.signUp({ email, password: pw, options: { data: { display_name: name }, emailRedirectTo: window.location.origin } }); setMsg(error ? error.message : 'Check your email to verify your account, then sign in.') }
    else { const { error } = await supabase.auth.resetPasswordForEmail(email, { redirectTo: window.location.origin }); setMsg(error ? error.message : 'If that email exists, a reset link is on its way.') }
    setBusy(false)
  }
  return <form onSubmit={submit} className="max-w-sm mx-auto space-y-3"><h1 className="text-2xl font-black">{mode === 'in' ? 'Sign in' : mode === 'up' ? 'Create account' : 'Reset password'}</h1>
    {mode === 'up' && <div><label className="label" htmlFor="n">Display name</label><input id="n" className="input" required value={name} onChange={e => setName(e.target.value)} /></div>}
    <div><label className="label" htmlFor="e">Email</label><input id="e" type="email" className="input" required value={email} onChange={e => setEmail(e.target.value)} /></div>
    {mode !== 'reset' && <div><label className="label" htmlFor="p">Password</label><input id="p" type="password" className="input" required value={pw} onChange={e => setPw(e.target.value)} /></div>}
    {msg && <p role="status" className="text-sm text-brand">{msg}</p>}
    <button className="btn w-full" disabled={busy}>{mode === 'in' ? 'Sign in' : mode === 'up' ? 'Sign up' : 'Send reset link'}</button>
    <div className="text-sm flex justify-between"><button type="button" className="underline" onClick={() => setMode(mode === 'in' ? 'up' : 'in')}>{mode === 'in' ? 'Create an account' : 'Back to sign in'}</button>{mode === 'in' && <button type="button" className="underline" onClick={() => setMode('reset')}>Forgot password?</button>}</div></form>
}
