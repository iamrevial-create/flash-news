import { useEffect, useState, useCallback } from 'react'
import { supabase } from '../lib/supabase'
import { useAuth } from '../lib/auth'
import type { Profile, Role } from '../lib/types'
import { useAutoRefresh } from '../lib/useAutoRefresh'
interface AppRow { id: string; publication_name: string; bio: string; country: string | null; website: string | null; status: string; user_id: string }
export default function Admin() {
  const { profile } = useAuth(); const admin = profile?.role === 'admin'; const [tab, setTab] = useState('apps')
  return <><h1 className="text-2xl font-black mb-3">Administration</h1>
    <div className="flex gap-2 mb-4">{[['apps', 'Applications'], ['comments', 'Comments'], ['reports', 'Reports'], ...(admin ? [['users', 'Users'], ['revenue', 'Revenue'], ['payouts', 'Payouts'], ['settings', 'Settings'], ['audit', 'Audit log']] : [])].map(([k, l]) => <button key={k} className={`btn ${tab === k ? '' : 'btn-ghost'}`} onClick={() => setTab(k)}>{l}</button>)}</div>
    {tab === 'apps' && <Apps />}{tab === 'users' && admin && <Users />}{tab === 'reports' && <Reports />}{tab === 'comments' && <CommentMod />}{tab === 'revenue' && admin && <Revenue />}{tab === 'payouts' && admin && <Payouts />}{tab === 'settings' && admin && <Settings />}{tab === 'audit' && admin && <Audit />}</>
}
export function Apps() {
  const [rows, setRows] = useState<AppRow[]>([]); const [reason, setReason] = useState<Record<string, string>>({}); const [msg, setMsg] = useState('')
  const load = useCallback(() => { supabase.from('publisher_applications').select('*').in('status', ['pending', 'info_requested']).order('created_at').then(({ data }) => setRows((data ?? []) as AppRow[])) }, []); useAutoRefresh(load)
  const decide = async (id: string, decision: string) => { const { error } = await supabase.rpc('decide_application', { app_id: id, decision, reason: reason[id] ?? '' }); error ? setMsg(error.message) : load() }
  return <>{msg && <p role="alert" className="text-brand">{msg}</p>}{!rows.length && <p className="text-gray-500">No open applications.</p>}
    {rows.map(r => <div key={r.id} className="border dark:border-gray-700 rounded p-3 mb-3"><b>{r.publication_name}</b> <span className="text-xs text-gray-500">{r.country} · {r.status}</span><p className="text-sm my-2">{r.bio}</p>{r.website && <a className="underline text-sm" href={r.website} target="_blank" rel="noopener nofollow">{r.website}</a>}
      <input className="input my-2" placeholder="Reason (required to reject or request info)" value={reason[r.id] ?? ''} onChange={e => setReason({ ...reason, [r.id]: e.target.value })} />
      <div className="flex gap-2"><button className="btn" onClick={() => decide(r.id, 'approved')}>Approve</button><button className="btn btn-ghost" onClick={() => decide(r.id, 'info_requested')}>Request info</button><button className="btn btn-ghost" onClick={() => decide(r.id, 'rejected')}>Reject</button></div></div>)}</>
}
function Users() {
  const [rows, setRows] = useState<Profile[]>([]); const [msg, setMsg] = useState('')
  const load = useCallback(() => { supabase.from('profiles').select('*').order('created_at', { ascending: false }).limit(200).then(({ data }) => setRows((data ?? []) as Profile[])) }, []); useAutoRefresh(load)
  const upd = async (id: string, patch: Partial<Profile>) => { const { error } = await supabase.from('profiles').update(patch).eq('id', id); error ? setMsg(error.message) : load() }
  return <>{msg && <p role="alert" className="text-brand">{msg}</p>}<div className="overflow-x-auto"><table className="w-full text-sm"><thead><tr className="text-left"><th>Name</th><th>Role</th><th>Status</th><th>Verified</th></tr></thead><tbody>
    {rows.map(u => <tr key={u.id} className="border-t dark:border-gray-700"><td className="py-2">{u.display_name}</td>
      <td><select aria-label={`Role for ${u.display_name}`} className="input !w-auto" value={u.role} onChange={e => upd(u.id, { role: e.target.value as Role })}>{['reader', 'applicant', 'publisher', 'reporter', 'editor', 'admin'].map(r => <option key={r}>{r}</option>)}</select></td>
      <td><select aria-label={`Status for ${u.display_name}`} className="input !w-auto" value={u.status} onChange={e => upd(u.id, { status: e.target.value as Profile['status'] })}><option>active</option><option>suspended</option></select></td>
      <td><input type="checkbox" aria-label="Verified" checked={u.verified} onChange={e => upd(u.id, { verified: e.target.checked })} /></td></tr>)}</tbody></table></div></>
}
export function Reports() {
  const [rows, setRows] = useState<{ id: string; kind: string; reason: string; resolved: boolean; articles: { slug: string; headline: string } | null }[]>([])
  const load = useCallback(() => { supabase.from('reports').select('id,kind,reason,resolved,articles(slug,headline)').order('created_at', { ascending: false }).limit(100).then(({ data }) => setRows((data ?? []) as any)) }, []); useAutoRefresh(load)
  return <>{!rows.length && <p className="text-gray-500">No reports.</p>}{rows.map(r => <div key={r.id} className="border-b py-2 dark:border-gray-700 text-sm flex justify-between gap-3"><div><b>{r.articles?.headline}</b> <span className="text-xs bg-soft dark:bg-gray-800 px-2 rounded">{r.kind}</span><p>{r.reason}</p></div>{!r.resolved && <button className="btn btn-ghost h-fit" onClick={() => supabase.from('reports').update({ resolved: true }).eq('id', r.id).then(load)}>Resolve</button>}</div>)}</>
}
function Audit() {
  const [rows, setRows] = useState<{ id: number; action: string; entity: string; created_at: string; detail: unknown }[]>([]); useEffect(() => { supabase.from('audit_logs').select('*').order('created_at', { ascending: false }).limit(100).then(({ data }) => setRows(data ?? [])) }, [])
  return <div className="text-xs font-mono">{rows.map(r => <div key={r.id} className="py-1 border-b dark:border-gray-700">{new Date(r.created_at).toLocaleString()} · {r.action} · {r.entity} · {JSON.stringify(r.detail)}</div>)}</div>
}

export function CommentMod() {
  const [rows, setRows] = useState<{ id: string; body: string; approved: boolean; reported: boolean; articles: { headline: string } | null }[]>([])
  const load = useCallback(() => { supabase.from('comments').select('id,body,approved,reported,articles(headline)').or('approved.eq.false,reported.eq.true').order('created_at').limit(100).then(({ data }) => setRows((data ?? []) as any)) }, []); useAutoRefresh(load)
  return <>{!rows.length && <p className="text-gray-500">No comments need moderation.</p>}{rows.map(c => <div key={c.id} className="border-b py-2 dark:border-gray-700 text-sm flex justify-between gap-3"><div><span className="text-xs text-gray-500">{c.articles?.headline}{c.reported && ' · reported'}</span><p>{c.body}</p></div>
    <div className="flex gap-2 h-fit">{!c.approved && <button className="btn" onClick={() => supabase.from('comments').update({ approved: true, reported: false }).eq('id', c.id).then(load)}>Approve</button>}{c.reported && c.approved && <button className="btn btn-ghost" onClick={() => supabase.from('comments').update({ reported: false }).eq('id', c.id).then(load)}>Keep</button>}<button className="btn btn-ghost" onClick={() => supabase.from('comments').delete().eq('id', c.id).then(load)}>Delete</button></div></div>)}</>
}

function Payouts() {
  const [rows, setRows] = useState<{ id: string; amount: number; currency: string; note: string; status: string; created_at: string; profiles: { display_name: string } | null }[]>([]); const [msg, setMsg] = useState('')
  const load = useCallback(() => { supabase.from('payout_requests').select('id,amount,currency,note,status,created_at,profiles(display_name)').order('created_at', { ascending: false }).limit(100).then(({ data }) => setRows((data ?? []) as any)) }, []); useAutoRefresh(load)
  const decide = async (id: string, status: 'paid' | 'rejected') => { const admin_note = status === 'rejected' ? prompt('Reason for rejecting?') : null; if (status === 'rejected' && !admin_note) return
    const { data: u } = await supabase.auth.getUser(); const { error } = await supabase.from('payout_requests').update({ status, admin_note, decided_by: u.user?.id, decided_at: new Date().toISOString() }).eq('id', id); error ? setMsg(error.message) : load() }
  return <>{msg && <p role="alert" className="text-brand">{msg}</p>}<p className="text-sm text-gray-500 mb-3">Pay the publisher yourself (bank transfer or mobile money), then press "Mark paid". The platform does not move money.</p>
    {!rows.length && <p className="text-gray-500">No payout requests.</p>}{rows.map(r => <div key={r.id} className="border dark:border-gray-700 rounded p-3 mb-2 text-sm flex justify-between gap-3 flex-wrap"><div><b>{r.profiles?.display_name}</b> · {r.currency} {r.amount} · <i>{r.status}</i><p>Pay to: {r.note}</p></div>{r.status === 'pending' && <div className="flex gap-2 h-fit"><button className="btn" onClick={() => decide(r.id, 'paid')}>Mark paid</button><button className="btn btn-ghost" onClick={() => decide(r.id, 'rejected')}>Reject</button></div>}</div>)}</>
}
function Settings() {
  const [v, setV] = useState({ amount: '0', currency: 'NGN', wa: '', adImg: '', adLink: '', adAlt: '' }); const [msg, setMsg] = useState('')
  useEffect(() => { supabase.from('site_settings').select('key,value').in('key', ['public.rate_per_1000_views', 'public.whatsapp_group', 'public.ad_banner']).then(({ data }) => {
    const m: Record<string, any> = Object.fromEntries((data ?? []).map(r => [r.key, r.value])); const r = m['public.rate_per_1000_views'] ?? {}, w = m['public.whatsapp_group'] ?? {}, a = m['public.ad_banner'] ?? {}
    setV({ amount: String(r.amount ?? 0), currency: r.currency ?? 'NGN', wa: w.url ?? '', adImg: a.image_url ?? '', adLink: a.link ?? '', adAlt: a.alt ?? '' }) }) }, [])
  const save = async () => { setMsg('')
    if (v.wa && !/^https:\/\/(chat\.whatsapp\.com|wa\.me)\//.test(v.wa)) return setMsg('WhatsApp link must start with https://chat.whatsapp.com/ or https://wa.me/')
    if ((v.adImg || v.adLink) && !(/^https:\/\//.test(v.adImg) && /^https:\/\//.test(v.adLink))) return setMsg('Banner image and link must both be https URLs.')
    const rows = [{ key: 'public.rate_per_1000_views', value: { amount: Math.max(0, Number(v.amount) || 0), currency: v.currency.toUpperCase().slice(0, 3) || 'NGN' } }, { key: 'public.whatsapp_group', value: { url: v.wa } }, { key: 'public.ad_banner', value: { image_url: v.adImg, link: v.adLink, alt: v.adAlt } }]
    const { error } = await supabase.from('site_settings').upsert(rows.map(r => ({ ...r, updated_at: new Date().toISOString() }))); setMsg(error ? error.message : 'Saved.') }
  const f = (k: keyof typeof v, label: string, type = 'text') => <div><label className="label" htmlFor={k}>{label}</label><input id={k} type={type} className="input" value={v[k]} onChange={e => setV({ ...v, [k]: e.target.value })} /></div>
  return <div className="max-w-xl space-y-3"><h2 className="font-bold">Publisher earnings</h2><div className="grid grid-cols-2 gap-3">{f('amount', 'Pay per 1,000 views', 'number')}{f('currency', 'Currency (3 letters)')}</div>
    <p className="text-xs text-gray-500">Set to 0 to switch earnings off. Publishers see estimates from real view counts; you pay them manually. Only raise this rate when you can afford to pay it.</p>
    <h2 className="font-bold pt-2">WhatsApp publishers group</h2>{f('wa', 'Invite link (shown on the publisher dashboard)')}
    <h2 className="font-bold pt-2">Homepage advertisement banner</h2>{f('adImg', 'Banner image URL (https)')}{f('adLink', 'Click-through link (https)')}{f('adAlt', 'Alt text')}
    <p className="text-xs text-gray-500">Leave blank for no banner. It is always labelled "Advertisement".</p>
    {msg && <p role="status" className="text-sm">{msg}</p>}<button className="btn" onClick={save}>Save settings</button></div>
}

interface Rev { id: string; source: string; amount: number; currency: string; period_start: string; period_end: string; note: string | null; creator_share_pct: number; editor_share_pct: number; distributed_at: string | null }
function Revenue() {
  const [rows, setRows] = useState<Rev[]>([]); const [msg, setMsg] = useState('')
  const today = new Date().toISOString().slice(0, 10)
  const [f, setF] = useState({ source: 'advertising', amount: '', currency: 'NGN', start: today, end: today, note: '', cpct: '40', epct: '10' })
  const load = useCallback(() => { supabase.from('revenue_entries').select('*').order('created_at', { ascending: false }).limit(50).then(({ data }) => setRows((data ?? []) as Rev[])) }, []); useAutoRefresh(load, 30000)
  const add = async () => { setMsg('')
    const amount = Number(f.amount), c = Number(f.cpct), e = Number(f.epct)
    if (!(amount > 0)) return setMsg('Enter the real amount received.'); if (c < 0 || e < 0 || c + e > 100) return setMsg('Shares must be between 0 and 100 and add up to 100 or less.'); if (f.end < f.start) return setMsg('End date is before start date.')
    const { error } = await supabase.from('revenue_entries').insert({ source: f.source, amount, currency: f.currency.toUpperCase().slice(0, 3), period_start: f.start, period_end: f.end, note: f.note || null, creator_share_pct: c, editor_share_pct: e })
    if (error) return setMsg(error.message); setF({ ...f, amount: '', note: '' }); load() }
  const dist = async (r: Rev) => { if (!confirm(`Share ${r.creator_share_pct}% by views and ${r.editor_share_pct}% among editors for ${r.period_start} to ${r.period_end}? This cannot be undone.`)) return
    const { data, error } = await supabase.rpc('distribute_revenue', { p_entry: r.id }); if (error) return setMsg(error.message)
    const d = data as { creators_paid: number; editors_paid: number }; setMsg(`Shared. ${d.creators_paid} publishers and ${d.editors_paid} editors credited.${!d.creators_paid && r.creator_share_pct > 0 ? ' No story views in that period, so the publisher share stayed with the platform.' : ''}${!d.editors_paid && r.editor_share_pct > 0 ? ' No editor approvals in that period, so the editor share stayed with the platform.' : ''}`); load() }
  const i = (k: keyof typeof f, label: string, type = 'text') => <div><label className="label" htmlFor={'r' + k}>{label}</label><input id={'r' + k} type={type} className="input" value={f[k]} onChange={e => setF({ ...f, [k]: e.target.value })} /></div>
  return <div className="space-y-4"><p className="text-sm text-gray-500 max-w-2xl">Record income you have <b>actually received</b> (advertising or sponsorship). Choose what percent goes to publishers (split by views of their published stories in the period) and to editors (split by stories they approved in the period). The rest stays with you. Only record real money, because publishers will ask to be paid from it.</p>
    <div className="grid sm:grid-cols-4 gap-3 max-w-3xl"><div><label className="label" htmlFor="rs">Source</label><select id="rs" className="input" value={f.source} onChange={e => setF({ ...f, source: e.target.value })}><option value="advertising">Advertising</option><option value="sponsorship">Sponsorship</option><option value="other">Other</option></select></div>
      {i('amount', 'Amount received', 'number')}{i('currency', 'Currency')}{i('note', 'Note (e.g. client, month)')}{i('start', 'Period start', 'date')}{i('end', 'Period end', 'date')}{i('cpct', 'Publishers get %', 'number')}{i('epct', 'Editors get %', 'number')}</div>
    <button className="btn" onClick={add}>Record income</button>{msg && <p role="status" className="text-sm">{msg}</p>}
    {rows.map(r => <div key={r.id} className="border dark:border-gray-700 rounded p-3 text-sm flex justify-between gap-3 flex-wrap"><div><b>{r.currency} {r.amount}</b> · {r.source} · {r.period_start} to {r.period_end}<p className="text-xs text-gray-500">Publishers {r.creator_share_pct}% · Editors {r.editor_share_pct}% {r.note && `· ${r.note}`}</p></div>
      {r.distributed_at ? <span className="text-xs bg-soft dark:bg-gray-800 px-2 py-1 rounded h-fit">Shared {new Date(r.distributed_at).toLocaleDateString()}</span> : <button className="btn h-fit" onClick={() => dist(r)}>Share with team</button>}</div>)}</div>
}
