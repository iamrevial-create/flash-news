import { useParams } from 'react-router-dom'
import Feed from '../components/Feed'
export default function TagPage() { const { slug } = useParams(); return <><h1 className="text-3xl font-black mb-4 border-b-2 border-brand pb-2">#{slug}</h1><Feed tagSlug={slug} /></> }
