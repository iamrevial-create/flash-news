import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { supabase } from '../lib/supabase'
import { useAuth } from '../lib/auth'
import type { Article } from '../lib/types'
import { timeAgo } from '../lib/util'
import { useAutoRefresh } from '../lib/useAutoRefresh'

export default function MyArticles() {
  const { session } = useAuth(); const [rows, setRows] = useState<Article[]>([]); const [st, setSt] = useState('')
  useAutoRefresh(() => { if (session) supabase.from('articles').select('id,slug,headline,status,review_note,updated_at').eq('author_id', session.user.id).order('updated_at', { ascending: false }).then(({ data }) => setRows((data ?? []) as Article[])) }, 15000, [session?.user.id])
  const [msg, setMsg] = useState('')
  const request = async (a: Article, kind: 'correction' | 'withdrawal') => { const reason = prompt(`Describe the ${kind} you are requesting:`); if (!reason?.trim() || !session) return
    const { error } = await supabase.from('reports').insert({ article_id: a.id, reporter_id: session.user.id, kind, reason: reason.trim() }); setMsg(error ? 'Could not send request.' : `Your ${kind} request was sent to the editors.`) }
  const shown = rows.filter(r => !st || r.status === st)
  return <><div className="flex justify-between items-center mb-4"><h1 className="text-2xl font-black">My articles</h1><div className="flex gap-2"><select aria-label="Filter by status" className="input !w-auto" value={st} onChange={e => setSt(e.target.value)}><option value="">All</option>{['draft','submitted','changes_requested','published','rejected'].map(s => <option key={s} value={s}>{s.replace('_', ' ')}</option>)}</select><Link className="btn" to="/publisher/articles/new">New story</Link></div></div>
    {msg && <p role="status" className="mb-3 text-sm">{msg}</p>}
    {shown.length ? shown.map(r => <div key={r.id} className="flex justify-between gap-3 py-3 border-b dark:border-gray-700 flex-wrap"><div><Link className="font-bold" to={`/news/${r.slug}`}>{r.headline}</Link><div className="text-xs text-gray-500">Updated {timeAgo(r.updated_at)}</div>{r.review_note && <div className="text-sm mt-1 bg-soft dark:bg-gray-800 p-2 rounded">Editor feedback: {r.review_note}</div>}</div>
      <div className="flex gap-2 items-start"><span className="text-xs bg-soft dark:bg-gray-800 px-2 py-1 rounded">{r.status.replace('_', ' ')}</span>{r.status === 'published' && <><button className="btn btn-ghost" onClick={() => request(r, 'correction')}>Request correction</button><button className="btn btn-ghost" onClick={() => request(r, 'withdrawal')}>Request withdrawal</button></>}{(r.status === 'draft' || r.status === 'changes_requested') && <Link className="btn btn-ghost" to={`/publisher/articles/${r.id}/edit`}>Edit</Link>}</div></div>) : <p className="text-gray-500">No stories yet.</p>}</>
}
