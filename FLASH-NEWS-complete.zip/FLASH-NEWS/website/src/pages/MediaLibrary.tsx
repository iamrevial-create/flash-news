import { useState, useCallback } from 'react'
import { supabase } from '../lib/supabase'
import { useAuth } from '../lib/auth'
import { useAutoRefresh } from '../lib/useAutoRefresh'
import { Media, mediaUrl, isVideo } from '../lib/media'
import { MEDIA_TYPES, MEDIA_IMAGE_MAX, MEDIA_VIDEO_MAX } from '../lib/util'
export default function MediaLibrary() {
  const { session } = useAuth(); const [rows, setRows] = useState<Media[]>([]); const [alt, setAlt] = useState(''); const [cap, setCap] = useState(''); const [msg, setMsg] = useState(''); const [busy, setBusy] = useState(false)
  const load = useCallback(() => { if (session) supabase.from('media_assets').select('*').eq('bucket', 'publisher-media').eq('owner_id', session.user.id).order('created_at', { ascending: false }).then(({ data }) => setRows((data ?? []) as Media[])) }, [session])
  useAutoRefresh(load, 30000, [session?.user.id])
  const upload = async (file?: File) => {
    if (!file || !session || busy) return; setMsg('')
    if (!MEDIA_TYPES.includes(file.type)) return setMsg('Allowed: JPEG, PNG, WebP images and MP4 or WebM videos.')
    const video = file.type.startsWith('video/')
    if (file.size > (video ? MEDIA_VIDEO_MAX : MEDIA_IMAGE_MAX)) return setMsg(video ? 'Videos must be 50 MB or smaller.' : 'Images must be 10 MB or smaller.')
    if (!video && !alt.trim()) return setMsg('Add alternative text describing the picture.')
    setBusy(true)
    const path = `${session.user.id}/${Date.now()}-${file.name.replace(/[^a-zA-Z0-9._-]/g, '_')}`
    const up = await supabase.storage.from('publisher-media').upload(path, file, { contentType: file.type })
    if (up.error) { setBusy(false); return setMsg(up.error.message) }
    const { error } = await supabase.from('media_assets').insert({ owner_id: session.user.id, bucket: 'publisher-media', path, alt_text: alt || null, caption: cap || null, mime: file.type, size_bytes: file.size })
    setBusy(false); if (error) return setMsg(error.message); setAlt(''); setCap(''); setMsg('Uploaded.'); load()
  }
  const del = async (m: Media) => { if (!confirm('Delete this file? Stories already using it will lose it.')) return; await supabase.storage.from('publisher-media').remove([m.path]); await supabase.from('media_assets').delete().eq('id', m.id); load() }
  const copy = (m: Media) => navigator.clipboard?.writeText(mediaUrl(m.path)).then(() => setMsg('Link copied.'))
  return <><h1 className="text-2xl font-black mb-1">Media library</h1><p className="text-sm text-gray-500 mb-4">Upload pictures (max 10 MB) and short videos (MP4 or WebM, max 50 MB). Use them inside your stories. Only upload content you own or have permission to publish.</p>
    <div className="grid sm:grid-cols-3 gap-3 p-4 bg-soft dark:bg-gray-800 rounded mb-6">
      <div><label className="label" htmlFor="alt">Alt text (required for pictures)</label><input id="alt" className="input" value={alt} onChange={e => setAlt(e.target.value)} /></div>
      <div><label className="label" htmlFor="cap">Caption (optional)</label><input id="cap" className="input" value={cap} onChange={e => setCap(e.target.value)} /></div>
      <div><label className="label" htmlFor="f">File</label><input id="f" type="file" accept={MEDIA_TYPES.join(',')} disabled={busy} onChange={e => { upload(e.target.files?.[0]); e.target.value = '' }} /></div></div>
    {msg && <p role="status" className="mb-3 text-sm">{busy ? 'Uploading…' : msg}</p>}
    {!rows.length && <p className="text-gray-500">No media yet.</p>}
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">{rows.map(m => <div key={m.id} className="border dark:border-gray-700 rounded overflow-hidden">
      {isVideo(m) ? <video src={mediaUrl(m.path)} controls preload="metadata" className="w-full aspect-video bg-black" /> : <img src={mediaUrl(m.path)} alt={m.alt_text ?? ''} loading="lazy" className="w-full aspect-video object-cover" />}
      <div className="p-2 text-xs"><p>{m.caption || m.alt_text || 'Untitled'} · {isVideo(m) ? 'video' : 'picture'} · {((m.size_bytes ?? 0) / 1048576).toFixed(1)} MB</p>
        <div className="flex gap-2 mt-2"><button className="btn btn-ghost" onClick={() => copy(m)}>Copy link</button><button className="btn btn-ghost" onClick={() => del(m)}>Delete</button></div></div></div>)}</div></>
}
