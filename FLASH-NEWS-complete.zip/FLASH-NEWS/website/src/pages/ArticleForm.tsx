import { useEffect, useRef, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { supabase } from '../lib/supabase'
import { useAuth } from '../lib/auth'
import { Category, CONTENT_TYPES } from '../lib/types'
import { ALLOWED_IMAGES, MAX_IMAGE, isHttpUrl, parseTags, toEmbed } from '../lib/util'
import { Media, MEDIA_BASE, mediaUrl, isVideo } from '../lib/media'
import { Link } from 'react-router-dom'
const blank = { headline: '', subheadline: '', summary: '', body: '', category_id: 1, content_type: 'original_reporting', byline: '', featured_image_url: '', image_alt: '', image_caption: '', video_url: '', location: '', source_note: '', is_sponsored: false, sources: '', tags: '' }
export default function ArticleForm() {
  const { id } = useParams(); const nav = useNavigate(); const { session, profile } = useAuth()
  const [f, setF] = useState({ ...blank, byline: profile?.display_name ?? '' }); const [cats, setCats] = useState<Category[]>([]); const [errs, setErrs] = useState<string[]>([]); const [busy, setBusy] = useState(false)
  const [media, setMedia] = useState<Media[]>([]); const [pick, setPick] = useState(''); const [note, setNote] = useState(''); const dirty = useRef(false); const [locked, setLocked] = useState('')
  useEffect(() => { if (session) supabase.from('media_assets').select('*').eq('bucket', 'publisher-media').eq('owner_id', session.user.id).order('created_at', { ascending: false }).then(({ data }) => setMedia((data ?? []) as Media[])) }, [session])
  useEffect(() => { supabase.from('categories').select('*').order('sort').then(({ data }) => setCats((data ?? []) as Category[])) }, [])
  useEffect(() => { if (!id) return
    Promise.all([supabase.from('articles').select('*').eq('id', id).maybeSingle(), supabase.from('article_sources').select('label,url').eq('article_id', id), supabase.from('article_tags').select('tags(name)').eq('article_id', id)]).then(([a, s, t]) => {
      const d = a.data as any; if (!d) return setLocked('Story not found.')
      if (!['draft', 'changes_requested'].includes(d.status)) return setLocked(`This story is "${d.status}" and can no longer be edited.`)
      setNote(d.review_note ?? ''); setF({ ...blank, ...Object.fromEntries(Object.keys(blank).map(k => [k, d[k] ?? (blank as any)[k]])), tags: (t.data ?? []).map((x: any) => x.tags?.name).filter(Boolean).join(', '), sources: (s.data ?? []).map((x: any) => x.url ? `${x.label ? x.label + ' | ' : ''}${x.url}` : x.label).join('\n') }) }) }, [id])
  useEffect(() => { const h = (e: BeforeUnloadEvent) => { if (dirty.current) e.preventDefault() }; window.addEventListener('beforeunload', h); return () => window.removeEventListener('beforeunload', h) }, [])
  const set = (k: string, v: string | boolean | number) => { dirty.current = true; setF(p => ({ ...p, [k]: v })) }
  const upload = async (file?: File) => {
    if (!file || !session) return
    if (!ALLOWED_IMAGES.includes(file.type)) return setErrs(['Image must be JPEG, PNG or WebP.'])
    if (file.size > MAX_IMAGE) return setErrs(['Image must be 5 MB or smaller.'])
    const path = `${session.user.id}/${Date.now()}-${file.name.replace(/[^a-zA-Z0-9._-]/g, '_')}`
    const { error } = await supabase.storage.from('article-images').upload(path, file, { contentType: file.type })
    if (error) return setErrs([error.message]); set('featured_image_url', supabase.storage.from('article-images').getPublicUrl(path).data.publicUrl)
  }
  const save = async (submit: boolean) => {
    if (busy || !session) return
    const e: string[] = []
    if (f.headline.trim().length < 5 || f.headline.length > 160) e.push('Headline must be 5 to 160 characters.')
    if (f.summary.length > 400) e.push('Summary must be 400 characters or fewer.')
    if (f.featured_image_url && !isHttpUrl(f.featured_image_url)) e.push('Image URL is invalid.')
    if (f.featured_image_url && !f.image_alt.trim()) e.push('Add alternative text for the image.')
    if (f.video_url && !toEmbed(f.video_url, MEDIA_BASE)) e.push('Video must be a YouTube or Vimeo link, or a video from your media library.')
    const srcLines = f.sources.split('\n').map(s => s.trim()).filter(Boolean)
    for (const l of srcLines) { const u = l.includes('|') ? l.split('|').pop()!.trim() : l; if (/^https?:/i.test(u) === false && l.includes('|')) e.push(`Bad source link: ${l}`) }
    if (submit) { if (f.body.trim().length < 200) e.push('The story needs at least 200 characters before review.'); if (!f.summary.trim()) e.push('A summary is required to submit.'); if (f.content_type === 'external' && !srcLines.length) e.push('Externally sourced stories need at least one source.') }
    setErrs(e); if (e.length) return
    setBusy(true)
    const { sources, tags, ...rest } = f
    const row = { ...rest, headline: f.headline.trim(), category_id: Number(f.category_id), featured_image_url: f.featured_image_url || null, subheadline: f.subheadline || null, video_url: f.video_url || null, location: f.location || null, source_note: f.source_note || null, status: submit ? 'submitted' : 'draft' }
    const res = id ? await supabase.from('articles').update(row).eq('id', id).select('id').single() : await supabase.from('articles').insert(row).select('id').single()
    if (res.error || !res.data) { setBusy(false); return setErrs([res.error?.message ?? 'Save failed']) }
    const aid = res.data.id
    await supabase.from('article_sources').delete().eq('article_id', aid)
    if (srcLines.length) await supabase.from('article_sources').insert(srcLines.map(l => l.includes('|') ? { article_id: aid, label: l.split('|')[0].trim(), url: l.split('|').pop()!.trim() } : isHttpUrl(l) ? { article_id: aid, url: l } : { article_id: aid, label: l }))
    const wanted = parseTags(tags)
    await supabase.from('article_tags').delete().eq('article_id', aid)
    if (wanted.length) {
      const { data: have } = await supabase.from('tags').select('id,slug').in('slug', wanted.map(t => t.slug))
      const missing = wanted.filter(t => !(have ?? []).some(h => h.slug === t.slug))
      if (missing.length) await supabase.from('tags').insert(missing)
      const { data: all } = await supabase.from('tags').select('id').in('slug', wanted.map(t => t.slug))
      if (all?.length) await supabase.from('article_tags').insert(all.map(t => ({ article_id: aid, tag_id: t.id })))
    }
    dirty.current = false; nav('/publisher/articles')
  }
  if (locked) return <p>{locked}</p>
  const F = ({ k, label, area, type }: { k: keyof typeof blank; label: string; area?: number; type?: string }) => <div><label className="label" htmlFor={k}>{label}</label>{area ? <textarea id={k} rows={area} className="input" value={String(f[k])} onChange={e => set(k, e.target.value)} /> : <input id={k} type={type} className="input" value={String(f[k])} onChange={e => set(k, e.target.value)} />}</div>
  return <div className="max-w-3xl mx-auto space-y-3"><h1 className="text-2xl font-black">{id ? 'Edit story' : 'New story'}</h1>
    {note && <p className="p-3 bg-soft dark:bg-gray-800 rounded text-sm"><b>Editor feedback:</b> {note}</p>}
    {F({ k: 'headline', label: 'Headline' })}{F({ k: 'subheadline', label: 'Subheadline' })}{F({ k: 'summary', label: 'Summary (max 400 characters)', area: 3 })}
    <div className="grid sm:grid-cols-2 gap-3"><div><label className="label" htmlFor="cat">Category</label><select id="cat" className="input" value={f.category_id} onChange={e => set('category_id', Number(e.target.value))}>{cats.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}</select></div>
      <div><label className="label" htmlFor="ct">Content type</label><select id="ct" className="input" value={f.content_type} onChange={e => set('content_type', e.target.value)}>{CONTENT_TYPES.map(([v, l]) => <option key={v} value={v}>{l}</option>)}</select></div></div>
    {F({ k: 'body', label: 'Story. Blank line between paragraphs; start a line with "## " for a heading or "> " for a quote', area: 16 })}
    {F({ k: 'tags', label: 'Tags (comma separated, up to 8)' })}{F({ k: 'byline', label: 'Byline' })}
    <div><label className="label" htmlFor="img">Featured image (JPEG, PNG, WebP, max 5 MB)</label><input id="img" type="file" accept="image/jpeg,image/png,image/webp" onChange={e => upload(e.target.files?.[0])} />{f.featured_image_url && <img src={f.featured_image_url} alt="" className="mt-2 h-32 rounded" />}</div>
    <div className="p-3 bg-soft dark:bg-gray-800 rounded text-sm"><label className="label" htmlFor="mp">Use a file from your media library</label><div className="flex gap-2 flex-wrap"><select id="mp" className="input !w-auto min-w-[14rem]" value={pick} onChange={e => setPick(e.target.value)}><option value="">Choose a file…</option>{media.map(m => <option key={m.id} value={m.id}>{isVideo(m) ? '🎬' : '🖼'} {m.caption || m.alt_text || m.path.split('/').pop()}</option>)}</select>
      <button type="button" className="btn btn-ghost" disabled={!pick} onClick={() => { const m = media.find(x => x.id === pick); if (!m) return; if (isVideo(m)) set('video_url', mediaUrl(m.path)); else { set('featured_image_url', mediaUrl(m.path)); if (m.alt_text) set('image_alt', m.alt_text); if (m.caption) set('image_caption', m.caption) } }}>Use in this story</button><Link className="underline self-center" target="_blank" to="/publisher/media">Upload new</Link></div></div>
    {F({ k: 'image_alt', label: 'Image alternative text' })}{F({ k: 'image_caption', label: 'Image caption' })}
    {F({ k: 'sources', label: 'Sources and links, one per line ("Label | https://link" or just a link)', area: 4 })}{F({ k: 'source_note', label: 'Source attribution note (optional)' })}
    {F({ k: 'video_url', label: 'Video URL (YouTube, Vimeo or your library video, optional)' })}{F({ k: 'location', label: 'Story location (optional)' })}
    <label className="flex gap-2 text-sm"><input type="checkbox" checked={f.is_sponsored} onChange={e => set('is_sponsored', e.target.checked)} /> This is sponsored or promotional content</label>
    {errs.length > 0 && <ul role="alert" className="text-brand text-sm list-disc ml-5">{errs.map(x => <li key={x}>{x}</li>)}</ul>}
    <div className="flex gap-2"><button className="btn btn-ghost" disabled={busy} onClick={() => save(false)}>Save draft</button><button className="btn" disabled={busy} onClick={() => save(true)}>Submit for review</button></div></div>
}
